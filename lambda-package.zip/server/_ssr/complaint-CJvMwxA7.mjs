const complaint = `<h2>Complain Form
</h2>				
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sidead89db .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Instruction
</h2>				
		<p>1. Name of Applicant: Fill name of Applicant as mentioned on the Aadhaar Card.<br />"आधार कार्ड में उल्लिखित आवेदक का नाम भरें।"</p><p>2. Mobile No: Fill the correct Mobile Number of Applicant<br />"आवेदक का सही मोबाइल नंबर यहां लिखें।"</p><p>3. Mail ID: Fill the correct Mail ID of Applicant<br />"यहां अपनी सही ईमेल आईडी का उल्लेख करें।"</p><p>4. Do you have GSTIN Number?: If you have GSTIN number then select yes otherwise no and If you select yes Fill the correct GSTIN number<br />"अगर आपके पास GSTIN नंबर है तो हां का चयन करें अन्यथा नहीं और यदि आप हाँ का चयन करते हैं तो सही GSTIN नंबर भरें"</p><p>5. Gender: Select the gender from provided option<br />"आवेदक का लिंग चुनें।"</p><p>6. Name of Enterprise / Business: Fill the name of Business / Enterprise which will get printed on MSME Certificate.<br />"यहां अपने व्यवसाय के नाम का उल्लेख करें। यह नाम MSME प्रमाणपत्र पर मुद्रित किया जाएगा।"</p><p>7. Type of Organization: Select the type of organization from the given options which will get printed on MSME Certificate.<br />"दिए गए विकल्पों में से संगठन के प्रकार का चयन करें।"</p><p>8. Office Address: Please provide office address.<br />"दिए गए क्षेत्रों में ठीक से आधिकारिक पता लिखे |"</p><p>9. Main Business Activity of Enterprise: Select the Main Business activity from the given options.<br />"अपनी मुख्य व्यावसायिक गतिविधि चुनें।"</p>`;
export {
  complaint as default
};
