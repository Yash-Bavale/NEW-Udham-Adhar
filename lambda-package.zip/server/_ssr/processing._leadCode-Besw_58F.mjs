import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { C as CustomerRefGate, u as useCustomerLeadCode } from "./CustomerRefGate-CgpuDsbf.mjs";
import { e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { ak as captureAccessToken, b as trackEvent, T as TrustBlock } from "./router-B9F29-NE.mjs";
import { C as CountdownCard } from "./CountdownCard-CLgNMu1z.mjs";
import "../_libs/seroval.mjs";
import "../_libs/sonner.mjs";
import "./index.mjs";
import { w as ShieldCheck, b3 as FileCheckCorner, ao as Sparkles, l as CircleCheck } from "../_libs/lucide-react.mjs";
import "./customer-access.functions-DrNtSWTN.mjs";
import "./createSsrRpc-BvCR3awX.mjs";
import "./server-BOTfbN7Y.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:stream";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/seroval-plugins.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "./auth-middleware-DFG07yjQ.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/zod.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./constants-CKRzJJF_.mjs";
import "./client.functions-DdNhGH8Z.mjs";
import "./customer-access-core-Bd_9lLsD.mjs";
import "./brand-DLB0j9eh.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "../_libs/radix-ui__react-tabs.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/@radix-ui/react-use-is-hydrated+[...].mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "./datetime-DvkGwlJs.mjs";
import "./orders-filter-CXWoZisU.mjs";
import "./computeOrderStage-D7ejTUnj.mjs";
import "./consultation-asWR5IET.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-popover.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "./roles-CFhgFhhh.mjs";
import "./permissions.functions-BZcIYMbD.mjs";
import "./client-BX5UfqqR.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/lovable.dev__webhooks-js.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "./registry-DV_lUXjY.mjs";
import "../_libs/react-email__html.mjs";
import "../_libs/react-email__head.mjs";
import "../_libs/react-email__preview.mjs";
import "../_libs/react-email__body.mjs";
import "../_libs/react-email__container.mjs";
import "../_libs/react-email__heading.mjs";
import "../_libs/react-email__text.mjs";
import "../_libs/react-email__section.mjs";
import "../_libs/react-email__button.mjs";
import "../_libs/react-email__hr.mjs";
import "../_libs/date-fns.mjs";
import "../_libs/react-day-picker.mjs";
import "../_libs/date-fns__tz.mjs";
import "../_libs/motion.mjs";
import "../_libs/framer-motion.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
const TOTAL_SECONDS = 30;
const STEPS = [{
  at: 0,
  icon: ShieldCheck,
  label: "Securing your details",
  sub: "Encrypting personal information"
}, {
  at: 8,
  icon: FileCheckCorner,
  label: "Validating application data",
  sub: "Cross-checking required fields"
}, {
  at: 15,
  icon: Sparkles,
  label: "Running compliance checks",
  sub: "Aligning with MSME guidelines"
}, {
  at: 22,
  icon: CircleCheck,
  label: "Finalising your application",
  sub: "Almost done…"
}];
function ProcessingPage() {
  const leadCode = useCustomerLeadCode();
  const navigate = useNavigate();
  const [elapsed, setElapsed] = reactExports.useState(0);
  reactExports.useEffect(() => {
    captureAccessToken(leadCode);
    trackEvent("processing_viewed", {});
    if (typeof window !== "undefined") {
      const fireConversion = () => {
        if (window.gtag) {
          window.gtag("event", "conversion", {
            send_to: "AW-18336340451/7BVbCOm2p9wcEOOzuadE"
          });
        }
      };
      if (window.gtag) {
        fireConversion();
      } else {
        const t = setTimeout(fireConversion, 2e3);
        return () => clearTimeout(t);
      }
    }
  }, []);
  reactExports.useEffect(() => {
    if (elapsed >= TOTAL_SECONDS) {
      navigate({
        to: "/apply/$leadCode/summary",
        params: {
          leadCode
        },
        replace: true
      });
      return;
    }
    const t = setTimeout(() => setElapsed((s) => s + 1), 1e3);
    return () => clearTimeout(t);
  }, [elapsed, leadCode, navigate]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(CountdownCard, { totalSeconds: TOTAL_SECONDS, elapsed, steps: STEPS, leadCode }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(TrustBlock, {})
  ] });
}
function ProcessingPageGated() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(CustomerRefGate, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(ProcessingPage, {}) });
}
export {
  ProcessingPageGated as component
};
