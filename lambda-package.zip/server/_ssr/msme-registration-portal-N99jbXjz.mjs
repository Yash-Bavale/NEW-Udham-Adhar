const msmeRegistrationPortal = `<h2>MSME Registration Portal - Official Site for MSME Registration</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sid6114c7b .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>MSME Registration Portal - Official Site for MSME Registration</h1>				
											<a href="/">
						<h1>
				MSME Registration Portal - Official Site for MSME Registration
			</h1 > 
									</a>
		<p>The MSME registration portal is the official government website for registering micro, small, or medium enterprises in India. It provides a secure, paperless, and free registration process through Aadhaar-based verification. Entrepreneurs can complete the registration online, obtain a unique Udyam Registration Number, and instantly receive a digitally signed MSME certificate. This certificate acts as legal proof of business status and allows access to government schemes, loans, subsidies, and priority procurement benefits. The portal also enables businesses to update details, download certificates, and maintain compliance with regulatory requirements. By using the MSME registration portal, startups and established enterprises can ensure credibility, uninterrupted access to benefits, and seamless participation in government-supported programs for growth and sustainability.</p>
`;
export {
  msmeRegistrationPortal as default
};
