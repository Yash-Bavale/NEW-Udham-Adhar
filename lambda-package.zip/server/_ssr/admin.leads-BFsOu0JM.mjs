import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { O as Outlet } from "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "../_libs/cookie-es.mjs";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
const SplitComponent = () => /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {});
export {
  SplitComponent as component
};
