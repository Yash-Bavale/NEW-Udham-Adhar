const udyamRegistrationCheck = `<h2>Udyam Registration Check | Verify MSME Status Online</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sid9dcc4e5 .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyam Registration Check | Verify MSME Status Online</h1>				
											<a href="/">
						<h1>Udyam Registration Check | Verify MSME Status Online</h1> 
									</a>
<h2><a href="/">Udyam Registration Check | Verify MSME Status Online</a></h2>
		<p>Udyam Registration Check allows businesses to verify the status of their MSME registration online. By entering your Udyam Number, PAN, or Aadhaar details, you can confirm whether your registration is active, pending, or requires updates. This verification ensures eligibility for bank loans, tenders, government subsidies, and other official schemes. The process is fast, secure, and completely digital, with step-by-step guidance provided for accurate results. Regularly checking Udyam Registration status ensures compliance, prevents disruptions in accessing benefits, and maintains business credibility. This service is essential for micro, small, and medium enterprises to stay officially recognized and operationally ready.</p>
`;
export {
  udyamRegistrationCheck as default
};
