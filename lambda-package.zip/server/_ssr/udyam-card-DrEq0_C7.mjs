const udyamCard = `<h2>Udyam Card - Official MSME Registration Card</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sidd7498ac .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyam Card - Official MSME Registration Card</h1>				
											<a href="/">
						<h1>
				Udyam Card - Official MSME Registration Card
			</h1 > 
									</a>
		<p>The Udyam card is the official digital MSME registration card issued to businesses after successful registration on the Udyam portal. It contains the unique Udyam Registration Number, business details, and digital verification. The card serves as proof of MSME status, allowing businesses to access government schemes, loans, subsidies, and procurement benefits. Entrepreneurs can download the card anytime online, ensuring they have instant and secure access to official certification. The Udyam card simplifies verification by banks, clients, and government authorities while maintaining compliance with regulations. It also allows businesses to update registration details and continue availing MSME benefits seamlessly. By holding a Udyam card, startups, small businesses, and medium enterprises gain credibility, formal recognition, and eligibility for financial and operational support programs aimed at promoting growth and sustainability.</p>
`;
export {
  udyamCard as default
};
