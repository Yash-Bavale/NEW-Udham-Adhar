const contact = `<p>Thank you for visiting Business Help Services.</p><p>We are committed to providing professional consultancy, documentation support, communication handling, coordination assistance, and process-related support services in a simple, transparent, and convenient manner.</p><p>For any service-related queries, operational assistance, support requests, or communication regarding your order/application, users may contact us through the details provided below.</p>		
							<ul>
							<li>
							<svg aria-hidden="true" viewBox="0 0 640 512" xmlns="http://www.w3.org/2000/svg"><path d="M496 224c-79.59 0-144 64.41-144 144s64.41 144 144 144 144-64.41 144-144-64.41-144-144-144zm64 150.29c0 5.34-4.37 9.71-9.71 9.71h-60.57c-5.34 0-9.71-4.37-9.71-9.71v-76.57c0-5.34 4.37-9.71 9.71-9.71h12.57c5.34 0 9.71 4.37 9.71 9.71V352h38.29c5.34 0 9.71 4.37 9.71 9.71v12.58zM496 192c5.4 0 10.72.33 16 .81V144c0-25.6-22.4-48-48-48h-80V48c0-25.6-22.4-48-48-48H176c-25.6 0-48 22.4-48 48v48H48c-25.6 0-48 22.4-48 48v80h395.12c28.6-20.09 63.35-32 100.88-32zM320 96H192V64h128v32zm6.82 224H208c-8.84 0-16-7.16-16-16v-48H0v144c0 25.6 22.4 48 48 48h291.43C327.1 423.96 320 396.82 320 368c0-16.66 2.48-32.72 6.82-48z"></path></svg>						
										Working Hours: 10:00 AM to 05:00 PM (IST) (Sunday &amp; Public Holidays off)
									</li>
								<li>
											<a href="mailto:help@businesshelpservices.com">
										Email: help@businesshelpservices.com
											</a>
									</li>
								<li>
											<a href="tel:919767870331">
							<svg aria-hidden="true" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M497.39 361.8l-112-48a24 24 0 0 0-28 6.9l-49.6 60.6A370.66 370.66 0 0 1 130.6 204.11l60.6-49.6a23.94 23.94 0 0 0 6.9-28l-48-112A24.16 24.16 0 0 0 122.6.61l-104 24A24 24 0 0 0 0 48c0 256.5 207.9 464 464 464a24 24 0 0 0 23.4-18.6l24-104a24.29 24.29 0 0 0-14.01-27.6z"></path></svg>						
										Phone: +91-9767870331
											</a>
									</li>
								<li>
											<a href="#">
										Address: Koregaon Bk, Khed, Pune, Maharashtra – 410505, India
											</a>
									</li>
						</ul>
					<h2>Contact Us</h2>				
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sid6683623 .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
		<h4>COMMUNICATION &amp; SUPPORT</h4>
<ul>
<li>Official communication may ordinarily be conducted through email or other written communication channels.</li>
<li>Users are advised to regularly monitor their registered communication channels for updates, verification requests, confirmations, and operational communication.</li>
<li>For operational, verification, compliance, quality-control, and record-management purposes, users may be requested to communicate through written communication channels.</li>
<li>Customer support and communication are currently available only in Marathi, Hindi, and English languages.</li>
<li>Support response timelines are indicative and may vary depending upon workload, operational requirements, holidays, technical conditions, or external dependencies.</li>
</ul>
<p>&nbsp;</p>
<h4>BEFORE CONTACTING SUPPORT</h4>
<p>To help us assist you more efficiently, users are advised to keep the following details ready while contacting support:</p>
<ul>
<li>Registered Name</li>
<li>Registered Mobile Number</li>
<li>Registered Email Address</li>
<li>Order/Application Number</li>
<li>Payment Reference Number (if applicable)</li>
<li>Relevant screenshot or error details (if applicable)</li>
</ul>
<p>&nbsp;</p>
<h4>IMPORTANT DISCLAIMER</h4>
<p>Business Help Services is a private consultancy and assistance service provider.</p>
<ul>
<li>We are not affiliated with, authorized by, endorsed by, or associated with any government authority or department.</li>
<li>Services provided through this Platform are consultancy and assistance-based professional services.</li>
<li>Users may independently access official services directly through respective official portals wherever applicable.</li>
</ul>
<p>&nbsp;</p>
<p>We appreciate the opportunity to assist you and look forward to supporting your business, documentation, registration, and process-related requirements.</p>
<p><strong>Business Help Services</strong></p>
<p>
📧 Email: help@businesshelpservices.com<br>
📞 Phone: +91-9767870331<br>
📍 Koregaon Bk, Khed, Pune, Maharashtra – 410505, India
</p>		
					<h2>
For more information or Questions, Please contact our customer care.</h2>				
					<h6><a href="tel:9822100331">+91 9822100331</a></h6>				
					<h4><a href="mailto:governmentscheme99@gmail.com">Mail us at governmentscheme99@gmail.com</a></h4>				
					<figure><img src="https://udyamadhar.in/wp-content/uploads/2024/09/icons8-youtube-750.png" title="" alt="" loading="lazy" /></figure><h3>यूट्यूब चॅनल</h3><p>आमच्या चॅनलवर सरकारी योजना, आणि कृषी विषयावरील माहितीपूर्ण व्हिडिओ पहा. </p>				
					<a href="#">
				<svg aria-hidden="true" viewBox="0 0 576 512" xmlns="http://www.w3.org/2000/svg"><path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"></path></svg>			
									Subscribe
					</a>
					<figure><img src="https://udyamadhar.in/wp-content/uploads/2024/09/icons8-instagram-logo-750.png" title="" alt="" loading="lazy" /></figure><h3>इन्स्टाग्राम रील्स</h3><p>आमच्या Instagram अकाउंटवर आमच्या वेबसाइटवरील माहिती आणि अपडेट्स मिळवा. .</p>				
					<a href="#">
				<svg aria-hidden="true" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path></svg>			
									Follow
					</a>
					<figure><img width="480" height="480" src="https://udyamadhar.in/wp-content/uploads/2024/09/icons8-whatsapp-480-1.png" alt="" /></figure><h3>व्हाट्सॲप चॅनल</h3><p>आमच्या ग्रुपमध्ये सामील व्हा आणि सरकारी योजना, कृषी विषयावरील नियमित अपडेट्स मिळवा.</p>				
					<a href="#">
				<svg aria-hidden="true" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path></svg>			
									Follow
					</a>
					<figure><img src="https://udyamadhar.in/wp-content/uploads/2024/09/icons8-facebook-240.png" title="" alt="" loading="lazy" /></figure><h3>फेसबुक पेज</h3><p>आमच्या Facebook पेजला लाईक करा आणि आमच्या सरकारी योजना पोस्ट आणि अपडेट्स पहा.</p>				
					<a href="#">
				<svg aria-hidden="true" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"></path></svg>			
									Follow 
					</a>`;
export {
  contact as default
};
