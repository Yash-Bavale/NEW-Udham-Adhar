const udyamAadhaarDownloadPdf = `<h2>Udyam Aadhaar Download PDF – Get Your MSME Certificate</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sid4ac532b .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyam Aadhaar Download PDF – Get Your MSME Certificate</h1>				
											<a href="/">
						<h1>
				Udyam Aadhaar Download PDF – Get Your MSME Certificate
			</h1 > 
									</a>
		<p>Udyam Aadhaar Download PDF allows registered businesses to access their official MSME certificate digitally in PDF format through the Udyam portal. Using your unique URN and mobile OTP verification, you can download your certificate instantly for printing or storage. The PDF serves as official proof of MSME status and is essential for accessing government loans, subsidies, tenders, and financial schemes. This process is secure, fast, paperless, and available 24/7, enabling entrepreneurs to maintain compliance, showcase credibility, and leverage all benefits associated with Udyam registration. The digital format ensures convenience for both startups and established enterprises.</p>
`;
export {
  udyamAadhaarDownloadPdf as default
};
