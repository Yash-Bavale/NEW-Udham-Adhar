const udyamAadhaarStatus = `<h2>Udyam Aadhaar Status | Track Your MSME Registration Online</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sid073125a .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyam Aadhaar Status | Track Your MSME Registration Online</h1>				
											<a href="/">
						<h1>
				Udyam Aadhaar Status | Track Your MSME Registration Online
			</h1 > 
									</a>
		<p>Udyam Aadhaar Status allows entrepreneurs to track the current status of their MSME registration online. By entering your Udyam Registration Number, PAN, or Aadhaar details, you can quickly see whether your certificate is active, pending, or requires updates. The portal provides a secure and paperless platform for monitoring business compliance. Maintaining a valid Udyam Aadhaar ensures access to government subsidies, bank loans, tenders, and other MSME benefits. Step-by-step guidance helps users navigate the status-checking process with ease. Regularly checking your Udyam Aadhaar Status ensures your enterprise remains compliant and eligible for official support programs, offering peace of mind and uninterrupted business operations.</p>
`;
export {
  udyamAadhaarStatus as default
};
