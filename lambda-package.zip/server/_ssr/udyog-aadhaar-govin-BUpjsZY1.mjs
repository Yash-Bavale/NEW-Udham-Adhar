const udyogAadhaarGovin = `<h2>Udyog Aadhaar Govin – Official MSME Registration Support</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sid4d97506 .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyog Aadhaar Govin – Official MSME Registration Support</h1>				
											<a href="/">
						<h1>
				Udyog Aadhaar Govin – Official MSME Registration Support
			</h1 > 
									</a>
		<p>Udyog Aadhaar gov.in was the official government portal for MSME registration, UAN issuance, and verification. It allowed entrepreneurs to register small and medium enterprises using Aadhaar authentication and obtain a unique Udyog Aadhaar Number. Though now replaced by the Udyam Registration system, the portal continues to provide access to old UAN details, verification tools, and migration assistance. Aadhaar-based verification ensures secure access while maintaining the accuracy of historic MSME records. Businesses can check, update, and migrate their registration to Udyam, unlocking enhanced digital services, instant certificate issuance, and continued eligibility for government schemes, loans, subsidies, and procurement opportunities.</p>
`;
export {
  udyogAadhaarGovin as default
};
