const udyogAadhaarGovernmentIn = `<h2>Udyog Aadhaar Government Portal – MSME Registration Details</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sid8a96548 .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyog Aadhaar Government Portal – MSME Registration Details</h1>				
											<a href="/">
						<h1>
				Udyog Aadhaar Government Portal – MSME Registration Details
			</h1 > 
									</a>
		<p>Udyog Aadhaar Government Portal was the previous system used for MSME registration in India. It allowed businesses to obtain a Udyog Aadhaar Number (UAN), serving as official proof of enterprise status. While the system is still recognized, it has been replaced by the modern Udyam portal, which provides faster, paperless, and digitally signed MSME certificates. Entrepreneurs can still verify or update old UAN records online, but migrating to Udyam is recommended to enjoy enhanced digital services, instant certificate issuance, and seamless access to government schemes, loans, subsidies, and procurement benefits. The portal supported startups, small businesses, and medium enterprises in formalizing operations, accessing financial assistance, and maintaining compliance with government regulations.</p>
`;
export {
  udyogAadhaarGovernmentIn as default
};
