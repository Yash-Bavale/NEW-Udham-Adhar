const udyamAadhaarLogin = `<h2>Udyam Aadhaar Login | Access Your MSME Registration Online</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sidacdf579 .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyam Aadhaar Login | Access Your MSME Registration Online</h1>				
											<a href="/">
						<h1>
				Udyam Aadhaar Login | Access Your MSME Registration Online
			</h1 > 
									</a>
		<p>Udyam Aadhaar Login enables entrepreneurs to securely access their MSME Udyam certificate and registration details online. Using Aadhaar-linked OTP verification, businesses can view, update, or print certificates instantly. The portal provides a paperless, secure, and user-friendly interface for managing all MSME-related documentation. Logging in allows access to subsidy programs, bank loans, tenders, and other government schemes. Step-by-step guidance ensures a seamless login experience. Keeping your login details secure ensures uninterrupted access to official records, helping micro, small, and medium enterprises maintain compliance and stay ready for government support opportunities.</p>
`;
export {
  udyamAadhaarLogin as default
};
