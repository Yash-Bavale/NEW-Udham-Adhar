const downloadUdyam = `<h2>Udyam Free Registration - No Charges for MSME Registration</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sida5d14bb .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyam Free Registration - No Charges for MSME Registration</h1>				
											<a href="/">
						<h1>
				Udyam Free Registration - No Charges for MSME Registration
			</h1 > 
									</a>
		<p>Download Udyam refers to accessing your official MSME registration certificate online through the government’s Udyam portal. The registration and certificate download are completely free, with no charges or hidden fees. Entrepreneurs and business owners can obtain a digitally signed certificate that serves as proof of micro, small, or medium enterprise status. The certificate enables eligibility for government schemes, financial assistance, subsidies, and priority sector procurement opportunities. The download process is paperless, secure, and available 24/7, allowing businesses to store or print it for official purposes. By downloading Udyam, startups and established enterprises gain instant recognition, credibility, and access to a variety of support programs aimed at fostering business growth, expansion, and sustainability.</p>
`;
export {
  downloadUdyam as default
};
