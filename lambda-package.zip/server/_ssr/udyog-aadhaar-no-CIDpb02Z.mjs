const udyogAadhaarNo = `<h2>Udyog Aadhaar Number (UAN) – Find, Verify &amp; Update UAN</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sidfff1e46 .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyog Aadhaar Number (UAN) – Find, Verify &amp; Update UAN</h1>				
											<a href="/">
						<h1>
				Udyog Aadhaar Number (UAN) – Find, Verify &amp; Update UAN
			</h1 > 
									</a>
		<p>Udyog Aadhaar Number (UAN) is a unique identifier previously issued to micro, small, and medium enterprises (MSMEs) in India to avail government benefits, subsidies, and schemes. Entrepreneurs could register online with basic business details and Aadhaar authentication to obtain their UAN instantly. Existing businesses can retrieve their UAN easily through the portal for verification, corrections, or updates. Businesses are encouraged to migrate their UAN to the new Udyam Registration system for faster, paperless, and digitally signed MSME certification. Keeping your UAN active ensures continuity of benefits and seamless access to historic MSME data, including certificate downloads, tender participation, and loan applications. This unique identification helps maintain compliance, credibility, and government recognition while supporting small and medium enterprises in operational and financial growth.</p>
`;
export {
  udyogAadhaarNo as default
};
