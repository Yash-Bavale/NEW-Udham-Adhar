const udyamCardDownload = `<h2>Udyam Card Download – Get Your MSME Certificate Online</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sid77f3886 .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyam Card Download – Get Your MSME Certificate Online</h1>				
											<a href="/">
						<h1>
				Udyam Card Download – Get Your MSME Certificate Online
			</h1 > 
									</a>
		<p>Udyam Card Download allows businesses to obtain their official MSME registration card online through the Udyam portal. The card contains the Udyam Registration Number, business details, and digital verification, serving as proof of micro, small, or medium enterprise status. Downloading the card is free, secure, and instantly available in PDF format. Businesses can verify registration details before download, use OTP verification for security, and store the card for official use with banks, government authorities, or clients. The Udyam Card provides legal recognition, ensures uninterrupted access to government schemes, loans, subsidies, and procurement opportunities, and simplifies verification processes. It is a convenient, paperless tool to manage MSME certification and maintain compliance for startups and established enterprises.</p>
`;
export {
  udyamCardDownload as default
};
