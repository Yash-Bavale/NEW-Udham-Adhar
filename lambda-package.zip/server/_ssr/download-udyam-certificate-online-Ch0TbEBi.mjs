const downloadUdyamCertificateOnline = `<h2>Download Udyam</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sid125cf50 .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Download Udyam</h1>				
											<a href="/">
						<h1>
				Download Udyam
			</h1 > 
									</a>
		<p>Downloading your Udyam is a fast, secure, and paperless process available through the official government portal. Entrepreneurs can enter their Udyam Registration Number, complete OTP verification, and instantly access a digitally signed PDF certificate. This official document serves as proof of MSME registration and is required for loans, government tenders, subsidies, and other financial schemes. The process is designed for ease of use by micro, small, and medium enterprises, allowing instant retrieval anytime. Keeping a digital or printed copy ensures compliance with MSME regulations, demonstrates credibility, and supports operational and financial growth. The portal is user-friendly, accessible 24/7, and provides uninterrupted certificate download services for registered businesses.</p>
`;
export {
  downloadUdyamCertificateOnline as default
};
