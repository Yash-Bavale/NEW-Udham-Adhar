const udyamAdhaar = `<h2>Udyam Aadhaar - Aadhaar-Based Verification for MSME Registration</h2>
<p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>

                    <style>
                        .htmega-form-wrapper.sid94ca545 .wpcf7-select {
                                appearance: none;
                                background-image: url('https://udyamadhar.in/wp-content/plugins/ht-mega-for-elementor/assets/images/icons/select-arrow-icon.svg');
                                background-repeat: no-repeat;
                            }
                    </style>
					<h2>Sample Certificate</h2>				
																<a href="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="udyam-certificate-design-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6OTk0MSwidXJsIjoiaHR0cHM6XC9cL3VkeWFtYWRoYXIuaW5cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjZcLzA1XC91ZHlhbS1jZXJ0aWZpY2F0ZS1kZXNpZ24tMS53ZWJwIn0%3D">
							<img width="1110" height="1595" src="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp" alt="" srcset="/__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1110w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 209w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 713w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 768w, /__l5e/assets-v1/4fb73dad-846b-4c39-879e-ee54d21d1925/udyam-sample-certificate.webp 1069w" sizes="(max-width: 1110px) 100vw, 1110px" />								</a>
		<p>Note: Sample Udyam Certificate shown for reference purposes only.</p>		
					<h1>Udyam Aadhaar - Aadhaar-Based Verification for MSME Registration</h1>				
											<a href="/">
						<h1>
				Udyam Aadhaar - Aadhaar-Based Verification for MSME Registration
			</h1 > 
									</a>
		<p>Udyam Aadhaar links your personal Aadhaar number with your business to enable fast, secure, and paperless MSME registration on the government’s Udyam portal. This Aadhaar-based verification ensures authenticity and allows instant issuance of a digitally signed MSME certificate, serving as legal proof of enterprise status. The system simplifies registration, reduces paperwork, and allows easy updates of business information such as address, category, or contact details. By linking Aadhaar, entrepreneurs and businesses can access multiple government benefits, including loans, subsidies, priority lending, and participation in procurement tenders. Udyam Aadhaar ensures secure verification, formal recognition, and credibility with banks, financial institutions, and government authorities. The digital approach supports startups, small enterprises, and established businesses in obtaining official certification quickly, maintaining compliance, and leveraging government support for growth, market expansion, and long-term sustainability.</p>
`;
export {
  udyamAdhaar as default
};
